	<!-- Vendor JS -->
	<script src="{{ asset('admin/js/vendors.min.js') }}"></script>
	<!-- <script src="{{ asset('admin/js/pages/chat-popup.js') }}"></script>-->
    <script src="{{ asset('admin/assets/icons/feather-icons/feather.min.js') }}"></script> 
	
	<script src="{{ asset('admin/assets/vendor_components/Flot/jquery.flot.js') }}"></script>
	<script src="{{ asset('admin/assets/vendor_components/Flot/jquery.flot.resize.js') }}"></script>
	<script src="{{ asset('admin/assets/vendor_components/Flot/jquery.flot.pie.js') }}"></script>
	<script src="{{ asset('admin/assets/vendor_components/Flot/jquery.flot.categories.js') }}"></script>
	<!-- <script src="{{ asset('admin/www.amcharts.com/lib/3/amcharts.js') }}" type="text/javascript"></script>
	<script src="{{ asset('admin//www.amcharts.com/lib/3/gauge.js') }}" type="text/javascript"></script>
	<script src="{{ asset('admin/www.amcharts.com/lib/3/serial.js') }}" type="text/javascript"></script>
	<script src="{{ asset('admin/www.amcharts.com/lib/3/amstock.js') }}" type="text/javascript"></script>
	<script src="{{ asset('admin/www.amcharts.com/lib/3/pie.js') }}" type="text/javascript"></script>
	<script src="{{ asset('admin/www.amcharts.com/lib/3/plugins/dataloader/dataloader.min.js') }}"></script>
	<script src="{{ asset('admin/www.amcharts.com/lib/3/plugins/animate/animate.min.js') }}" type="text/javascript"></script>
	<script src="{{ asset('admin/www.amcharts.com/lib/3/plugins/export/export.min.js') }}" type="text/javascript"></script>
	<script src="{{ asset('admin/www.amcharts.com/lib/3/themes/patterns.js') }}" type="text/javascript"></script>
	<script src="{{ asset('admin/www.amcharts.com/lib/3/themes/light.js') }}" type="text/javascript"></script>	
	<script src="{{ asset('admin/assets/vendor_components/Web-Ticker-master/jquery.webticker.min.js') }}"></script>
	<script src="{{ asset('admin/assets/vendor_components/echarts-master/dist/echarts-en.min.js') }}"></script>
	<script src="{{ asset('admin/assets/vendor_components/echarts-liquidfill-master/dist/echarts-liquidfill.min.js') }}"></script>
    <script src="{{ asset('admin/assets/vendor_components/datatable/datatables.min.js') }}"></script>
	<script src="{{ asset('admin/assets/vendor_plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.js') }}"></script> -->
	
	<!-- Crypto Admin App -->
	<script src="{{ asset('admin/js/template.js') }}"></script>
	<script src="{{ asset('admin/js/pages/dashboard.js') }}"></script>
	<script src="{{ asset('admin/js/pages/dashboard-chart.js') }}"></script>
	<script src="{{ asset('admin/js/pages/data-table.js') }}"></script>
	<script src="{{ asset('assets/vendor_components/datatable/datatables.min.js') }}"></script>
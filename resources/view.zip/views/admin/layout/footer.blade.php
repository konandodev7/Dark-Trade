<footer class="main-footer">
    <div class="pull-right d-none d-sm-inline-block">
        <ul class="nav nav-primary nav-dotted nav-dot-separated justify-content-center justify-content-md-end">
		</ul>
    </div>
	  &copy; 2021 Dark Trade. All Rights Reserved.<a href="">Dark Trade</a>
  </footer>